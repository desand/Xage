<?php
$dashboard = array(
	/*'Dreg' => array(
		'q' => "SELECT count(*) as ctotal,count(`Reg_Date`) as cnum FROM `regs_attendees` WHERE `show_id`='".$this->show_id."'",
	),
	'Dticket' => array(
		'q' => "SELECT count(*) as ctotal,count(`ticket_id`) as cnum FROM `regs_attendees` WHERE `show_id`='".$this->show_id."'",
	),  */
);