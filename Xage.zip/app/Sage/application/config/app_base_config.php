<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//系统信息
$config['site']['company_url']	= 'http://www.seasonfair.com';
$config['site']['company_name']	= '广州师盛展览有限公司';

$config['site']['product_url']	= 'http://www.7-event.com';
$config['site']['product_name']	= '会讯易';

$config['site']['keywords'] = '会讯易';
$config['site']['title'] = '7-event 会议活动管理系统';
$config['site']['description'] = '';

$config['rpc']['url'] = '';
$config['rpc']['username'] = '';
$config['rpc']['password'] = '';

/* End of file app_base_config.php */
/* Location: ./application/config/app_base_config.php */
