<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$db['report']['hostname'] = 'localhost';
$db['report']['username'] = 'seasonfair';
$db['report']['password'] = '18608';
$db['report']['database'] = 'semi_report';
$db['report']['dbdriver'] = 'mysql';
$db['report']['dbprefix'] = '';
$db['report']['pconnect'] = FALSE;
$db['report']['db_debug'] = TRUE;
$db['report']['cache_on'] = FALSE;
$db['report']['cachedir'] = '';
$db['report']['char_set'] = 'utf8';
$db['report']['dbcollat'] = 'utf8_general_ci';
$db['report']['swap_pre'] = '';
$db['report']['autoinit'] = TRUE;
$db['report']['stricton'] = FALSE;