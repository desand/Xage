<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$db['schema']['hostname'] = 'localhost';
$db['schema']['username'] = 'seasonfair';
$db['schema']['password'] = '18608';
$db['schema']['database'] = 'INFORMATION_SCHEMA';
$db['schema']['dbdriver'] = 'mysql';
$db['schema']['dbprefix'] = '';
$db['schema']['pconnect'] = FALSE;
$db['schema']['db_debug'] = TRUE;
$db['schema']['cache_on'] = FALSE;
$db['schema']['cachedir'] = '';
$db['schema']['char_set'] = 'utf8';
$db['schema']['dbcollat'] = 'utf8_general_ci';
$db['schema']['swap_pre'] = '';
$db['schema']['autoinit'] = TRUE;
$db['schema']['stricton'] = FALSE;