<?php
require_once APPPATH . 'controllers/base_controller.php';
class Manage extends Base_Controller 
{
	private $url = '';
	private $data = array();
	private $show_id = FALSE;
	
	private $needverify = FALSE;
	private $role = __ROLE__;
	
	private $thisfields = array('barcode','company','A','B','C','D','E','name','F','G','H','I','J','mobile','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ','BA','BB','BC','BD','BE','BF','BG','BH','BI','BJ','BK','BL','BM','BN','BO','BP','BQ','BR','BS','BT','BU','BV','BW','BX','BY','BZ','CA','CB','CC','CD','CE','CF','CG','CH','CI','CJ','CK','CL','CM','CN','CO','CP','CQ','CR','CS','CT','CU','CV','CW','CX','CY','CZ','DA','DB','DC','DD','DE','DF','DG','DH','DI','DJ','DK','DL','DM','DN','DO','DP','DQ','DR','DS','DT','DU','DV','DW','DX','DY','DZ','EA','EB','EC','ED','EE','EF','EG','EH','EI','EJ','EK','EL','EM','EN','EO','EP','EQ','ER','ES','ET','EU','EV','EW');
	
	public function __construct()
	{
		parent::__construct();
		$this->url = strtolower(__CLASS__.'/'.$this->uri->rsegment(2));
		
		if($this->input->get('key')){
			$this->load->library('encrypt');
			$key = explode('_',$this->input->get('key'));
			if (count($key)==2 && $key[1] == $this->encrypt->encode($key[0],__KEY__)){
				$url = current_url().'/'.$key[0].'?token='.$key[1];
				redirect($url);
			}
		}
		$this->show_id = $this->_show_id;
		$this->data['show_id'] = $this->show_id;
		
		#verify
		if($this->needverify){
			if(!$this->Verify()){
				redirect('admin/user/logout','refresh');
			}
		}
		
		#site
		$this->load->config('app_base_config');
		$this->data['site'] = $this->config->item('site');
		
		#model
		$this->load->model('super_model');
	}
	/**
	 * @name index
	 * @author desand
	 * @version 2.0.0
	 */
	public function index()
	{
		$this->load->view($this->get_diy_view($this->url,$this->show_id),$this->data);
	}
	public function dashboard(){
		$this->load->view($this->get_diy_view($this->url,$this->show_id),$this->data);
	}
	public function xmlrequest(){
		header( 'Content-type: text/html; charset=utf-8' );
		echo '<script type="text/javascript" src="'.base_url().'material/js/jquery/jquery.js'.'"></script>';
		$target = $this->input->get('tar');
		if($target == ''){die;}
		
		$incfile = APPPATH.'component/'.$target.'/';
		$incfile = file_exists($incfile.$this->show_id.EXT)?$incfile.$this->show_id.EXT:(file_exists($incfile.$this->role.EXT)?$incfile.$this->role.EXT:$incfile.'default'.EXT);
		
		include APPPATH.'core/xanalysis'.EXT;
		switch ($target){
			case 'dashboard':{
				include $incfile;
				
				$i = 1;
				$total = count($$target);
				if($total > 0){
					foreach ($$target as $key => $each){
						$data = $this->regs_model->q($each['q']);
						
						if($i == $total){
							echo '<script type="text/javascript">$("#loading", parent.document).animate({"height":"'.($i/$total*120).'"},function(){setTimeout(function(){window.parent.init()},5);})</script>';
						}else{
							echo '<script type="text/javascript">$("#loading", parent.document).animate({"height":"'.($i/$total*120).'"})</script>';
						}
						echo '<script type="text/javascript">window.parent.showdata("'.$key.'",'.json_encode($data).')</script>';
						@flush();
						@ob_flush();
						usleep(1);
						++$i;
					}
				}else{
					echo '<script type="text/javascript">$("#loading", parent.document).animate({"height":"120"});setTimeout(function(){window.parent.init()},500);</script>';
				}
			
				break;
			}
			default:
				break;
		}
	}
	
	/**
	 * @name import
	 * load import page
	 * 
	 * @author desand
	 * @version 2.0.0
	 */
	public function import()
	{
		$this->load->view($this->get_diy_view($this->url,$this->show_id),$this->data);
	}
	
	/**
	 * @name listmatch
	 *
	 * @author desand
	 * @version 2.0.0
	 */
	public function listmatch()
	{
		if(!$this->input->post('id')){
			echo json_encode(array('error'=>'Invaild Data'));
			die();
		}
		$this->data['keys'] = array('barcode','name','H','B','AF','AI','AG','AK','AL','AH','Z','AA','AB','AC','AD','AM');
		$this->data['vals'] = array('二维码','姓名','身份证号','团号','护照号码','出生地','签发日期','发证机关','发证机关拼音','护照到期','中文姓名','汉语拼音','性别','出生日期','国籍','快递单号');
		
		$this->data['attendee'] = $this->super_model->q("SELECT `id`,`".implode('`,`',$this->data['keys'])."` FROM `regs_attendees_".$this->show_id."`");
		
		$this->super_model->set_table('analysis_upload_files');
		$this->data['details'] = $this->super_model->get_detail($this->input->post('id'));
		
		
		$this->load->view($this->get_diy_view($this->url,$this->show_id),$this->data);
	}
	/**
	 * @name domatch
	 * type ajax
	 *
	 * @author desand
	 * @version 2.0.0
	 */
	public function domatch()
	{
		$post = $this->input->post();
		if(isset($post['id']) && isset($post['params']) && count($post['params'])>0){
			$q = 'UPDATE `regs_attendees_'.$this->show_id.'` SET '.$this->drawUndateq($post['params']).' WHERE `id`=\''.$post['id'].'\'';
			$result = $this->super_model->q($q,FALSE);
			
			if($result){
				echo json_encode(array('ori'=>$post['ori']));
			}else{
				echo json_encode(array('error'=>'UPDATE DB Error'));
			}
		}else{
			echo json_encode(array('error'=>'Invaild Data'));
		}
		exit;
	}
	public function domatchall()
	{
		$posts = $this->input->post();
		if(count($posts)>0){
			$return = array();
			foreach($posts as $post){
				if(isset($post['id']) && isset($post['params']) && count($post['params'])>0){
					$q = 'UPDATE `regs_attendees_'.$this->show_id.'` SET '.$this->drawUndateq($post['params']).' WHERE `id`=\''.$post['id'].'\'';
					$result = $this->super_model->q($q,FALSE);
						
					if($result){
						$return[] = array('ori'=>$post['ori']);
					}
				}
			}
			if(count($return)>0){
				echo json_encode($return);
			}else{
				echo json_encode(array('error'=>'Invaild Data'));
			}
		}else{
			echo json_encode(array('error'=>'Invaild Data'));
		}
		exit;
	}
	
	/**
	 * @name analysis
	 * type ajax
	 *
	 * @author desand
	 * @version 2.0.0
	 */
	public function analysis()
	{
		$this->load->helper('file');
		$uploadurl = 'templates/assets/jquery-file-upload/server/php/files/';
		$files = get_filenames($uploadurl);
		$accept_file_types = array('xls','xlsx');
		
		$details = array();
		foreach($files as $i=>$file){
			#忽略不是 Excel 类型的文件
			if(!in_array(pathinfo($file,PATHINFO_EXTENSION),$accept_file_types)){
				unset($files[$i]);
			}else{
				#查找 Excel 文件是否被分析过
				$result = $this->super_model->q("SELECT `id`,`datetime`,`volume`,`status`,`result` FROM `analysis_upload_files` WHERE `filename`='".$file."' AND `status`=0");
				if(count($result)>0 && isset($result[0])){
					$result[0]['result'] = json_decode($result[0]['result'],true);
					$details[$i] = $result[0];
				}
			}
		}
		echo json_encode(array('files'=>$files,'details'=>$details));
		die();
	}
	
	/**
	 * @name doanalysis
	 * type ajax
	 *
	 * @author desand
	 * @version 2.0.0
	 */
	public function doanalysis()
	{
		if(!$this->input->post('id')){
			echo json_encode(array('error'=>'Invaild Data'));
			die();
		}
		$attendee = $this->super_model->q("SELECT `".implode('`,`',$this->thisfields)."` FROM `regs_attendees_".$this->show_id."`");
		//print_r($attendee);exit;
		
		$this->super_model->set_table('analysis_upload_files');
		$details = $this->super_model->get_detail($this->input->post('id'));
				
		$jsondata = json_decode($details['data'],true);
		if($jsondata == false || count($jsondata)<=0){
			echo json_encode(array('error'=>'Data Have Some Invaild Characters(数据中含有非法字符，请确保单元格内数据没有换号符)!'));
		}
		if(count($attendee)<=0){
			echo json_encode(array('error'=>'No Attendees Data!'));
		}
		//print_r($jsondata);
		
		$atom = array();
		$filter = array('ZA','ZB','ZC','ZD','ZE','ZF');
		$tarfilter = array();
		
		foreach($jsondata['key'] as $key=>$val){
			if(in_array($val,$filter)){
				unset($jsondata['key'][$key]);
				unset($jsondata['val'][$key]);
				$tarfilter[] = $key;
			}
		}
		
		foreach($jsondata['data'] as $each){
			foreach($tarfilter as $tf){
				unset($each[$tf]);;
			}
			$atom[] = array_combine($jsondata['key'], $each);  ;
		}
		//print_r($atom);
		$matcher = array(
			'name'=>'Z',
		);
		
		$match_result = $this->_array_match($attendee,$atom,$matcher);
		
		$return = array('matchno'=>count($match_result['name']['matchno']),
						'matchone'=>count($match_result['name']['matchone']),
						'matchmore'=>count($match_result['name']['matchmore']));
		
		$q = "UPDATE `analysis_upload_files` SET `result`='".$this->JSON($return)."',`result_details`='".$this->JSON($match_result)."' WHERE `id`='".$this->input->post('id')."'";
		$result = $this->super_model->q($q,FALSE);
		
		if($result){
			/*
			 * $result[$ori_k] = array(
				'matchno'=>array(),
				'matchone'=>array(),
				'matchmore'=>array()
			);
			 * */
			echo json_encode($return);
		}else{
			echo json_encode(array('error'=>'UPDATE DB Error'));
		}
		die();
	}
	
	/**
	 * @name doindb
	 * type ajax
	 *
	 * @author desand
	 * @version 2.0.0
	 */
	public function doindb()
	{
		if(!$this->input->post('filename')){
			echo json_encode(array('error'=>'No File'));
			die();
		}
		$url = 'templates/assets/jquery-file-upload/server/php/files/'.$this->input->post('filename');
		$data = $this->load_excel_file($url);
		
		
		
		$thisfields = array_merge($this->thisfields,array('ZA','ZB','ZC','ZD','ZE','ZF'));
		
		#判断数据是否符合格式
		if(intval($data['count'])>0 && count(array_diff($data['key'],$thisfields)) == 0){
			$datetime = date('Y-m-d H:i:s');
			$q = "INSERT INTO `analysis_upload_files` (`filename`,`datetime`,`volume`,`data`) VALUES ('".$this->input->post('filename')."','".$datetime."','".$data['count']."','".$this->JSON($data)."')";
			$result = $this->super_model->q($q,FALSE);
			if($result){
				echo json_encode(array('volume'=>$data['count'],'id'=>mysql_insert_id(),'datetime'=>$datetime));
			}else{
				$msg = json_encode(array('error'=>'Insert DB Error'));
				$q = "INSERT INTO `analysis_upload_files` (`filename`,`datetime`,`volume`,`result`) VALUES ('".$this->input->post('filename')."','".$datetime."','".$data['count']."','".$msg."')";
				$this->super_model->q($q,FALSE);
				echo $msg;
			}
		}else{
			echo json_encode(array('error'=>'File Not Match'));
		}
		
		die();
	}
	
	/**
	 * @name load_import_file
	 *
	 * @author desand
	 * @version 2.0.0
	 */
	private function load_excel_file($url)
	{
		error_reporting(E_ERROR);
	
		require_once APPPATH . 'libraries/PHPExcel/PHPExcel.php';
		ini_set("memory_limit","512M");
		set_time_limit(300);
		
		$inputFileType = PHPExcel_IOFactory::identify($url);
		$objReader = PHPExcel_IOFactory::createReader($inputFileType);
		//$objReader->setReadDataOnly(true);
	
		$objPHPExcel = $objReader->load($url);
		//$sheet_count = $objPHPExcel->getSheetCount();
		
		$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
	
		/*$col_num = 0;
		$col_max = 0;
	
		for ($s = 0; $s < 1; $s++)
		{
			$currentSheet = $objPHPExcel->getSheet($s);// 当前页
			$row_num = $currentSheet->getHighestRow();// 当前页行数
			$col_max = $currentSheet->getHighestColumn(); // 当前页最大列号
			
			if(strlen($col_max)==2){
				$col_num = $col_num==0?( (ord(substr($col_max,0,1)) - ord('A') + 1)*26+(ord(substr($col_max,1,1)) - ord('A') + 1) ):$col_num;
			}else{
				$col_num = $col_num==0?(ord($col_max) - ord('A') + 1):$col_num;
			}
			
			// 循环从第二行开始，第一行往往是表头
			for($i = 1; $i <= $row_num; $i++)
			{
				$cell_values = array();
				for($j = 0; $j < $col_num; $j++)
				{
					$thisj = '';
					$tj = floor($j/26);
					if($tj != 0){
						$thisj = chr($tj+64).''.chr(($j%26)+65);
					}else{
						$thisj = chr($j+65);
					}
					
					$address = $thisj . $i; // 单元格坐标
					$cell_values[] = addslashes($currentSheet->getCell($address)->getFormattedValue());
				}
				// 看看数据
				if(count($cell_values) == $col_num){
					$result['data'][] = $cell_values;
				}
			}
		}*/
	
		$result['count'] = count($sheetData)-2;
		$result['key'] = $sheetData[1];
		$result['val'] = $sheetData[2];
		
		unset($sheetData[1]);
		unset($sheetData[2]);
		$result['data'] = $sheetData;

		return $result;
	}
	
	private function _array_match($ori = FALSE,$atom = FALSE,$matcher = array('barcode'=>'barcode'))
	{
		$t_ori = array();
		$result = array();
		foreach($matcher as $ori_k => $atom_k){
			foreach($ori as $each){
				$t_ori[$ori_k][] = $each[$ori_k];
			}
			
			$result[$ori_k] = array(
				'matchno'=>array(),
				'matchone'=>array(),
				'matchmore'=>array()
			);
			
			foreach($atom as $each){
				//echo $each[$atom_k].'<br/>';
				$ismatch = count(array_intersect($t_ori[$ori_k], array($each[$atom_k])));
				if($ismatch == 0){
					$result[$ori_k]['matchno'][] = $each;
				}elseif($ismatch == 1){
					$result[$ori_k]['matchone'][] = $each;
				}else{
					$result[$ori_k]['matchmore'][] = $each;
				}
			}
		}
		return $result;
	}
	
	/**************************************************************
	 *
	*  使用特定function对数组中所有元素做处理
	*  @param  string  &$array     要处理的字符串
	*  @param  string  $function   要执行的函数
	*  @return boolean $apply_to_keys_also     是否也应用到key上
	*  @access public
	*
	*************************************************************/
	function arrayRecursive(&$array, $function, $apply_to_keys_also = false)
	{
		static $recursive_counter = 0;
		if (++$recursive_counter > 1000) {
			die('possible deep recursion attack');
		}
		foreach ($array as $key => $value) {
			if (is_array($value)) {
				$this->arrayRecursive($array[$key], $function, $apply_to_keys_also);
			} else {
				$array[$key] = $function($value);
			}
	
			if ($apply_to_keys_also && is_string($key)) {
				$new_key = $function($key);
				if ($new_key != $key) {
					$array[$new_key] = $array[$key];
					unset($array[$key]);
				}
			}
		}
		$recursive_counter--;
	}
	
	/**************************************************************
	 *
	*  将数组转换为JSON字符串（兼容中文）
	*  @param  array   $array      要转换的数组
	*  @return string      转换得到的json字符串
	*  @access public
	*
	*************************************************************/
	function JSON($array) {
		$this->arrayRecursive($array, 'urlencode', true);
		$json = json_encode($array);
		return urldecode($json);
	}
	
	function drawUndateq($array){
		$q = '';
		$i = 0;
		foreach($array as $k=>$v){
			if($i>0){
				$q .= ',';
			}
			$q .= '`'.$k.'`=\''.$v.'\'';
			$i++;
		}
		return $q;
	}
	
	function drawInsertq($array){
		$i = 0;
		$q = '';
		foreach($array as $key=>$val){
			if($i>0){
				$q .= ',';
			}
			$q .= '`'.$key.'`';
			$i++;
		}
		$q .= ') VALUES (';
		$i = 0;
		foreach($array as $key=>$val){
			if($i>0){
				$q .= ',';
			}
			$q .= '\''.(is_array($val)?implode(',',$val):$val).'\'';
			$i++;
		}
		$q .= ')';
	
		return $q;
	}
	
	function compare($a,$b){
		$result = array();
		foreach($a as $k=>$v){
			if(!isset($b[$k]) || $v != $b[$k]){
				$result[$k] = $v;
			}
		}
		return $result;
	}
	 
}
?>