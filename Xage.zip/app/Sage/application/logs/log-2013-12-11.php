<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-12-11 16:59:42 --> 404 Page Not Found --> manage/http:
ERROR - 2013-12-11 16:59:42 --> 404 Page Not Found --> manage/http:
ERROR - 2013-12-11 16:59:42 --> 404 Page Not Found --> manage/http:
