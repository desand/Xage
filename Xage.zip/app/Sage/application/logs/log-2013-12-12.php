<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-12-12 17:24:06 --> 404 Page Not Found --> manage/favicon.ico
ERROR - 2013-12-12 17:24:07 --> 404 Page Not Found --> manage/favicon.ico
