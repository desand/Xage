<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-12-13 10:48:24 --> 404 Page Not Found --> manage/analysis
ERROR - 2013-12-13 10:50:11 --> 404 Page Not Found --> manage/analysis
ERROR - 2013-12-13 11:03:09 --> Severity: Notice  --> Undefined variable: show_id C:\VertrigoServ\www\Xage\app\Sage\application\views\manage\63\import.php 110
ERROR - 2013-12-13 11:03:18 --> Severity: Notice  --> Undefined property: CI_Loader::$show_id C:\VertrigoServ\www\Xage\app\Sage\application\views\manage\63\import.php 110
ERROR - 2013-12-13 11:12:32 --> Severity: Warning  --> opendir(./path/to/file.php,./path/to/file.php) [<a href='function.opendir'>function.opendir</a>]: ϵͳ�Ҳ���ָ����·���� (code: 3) C:\VertrigoServ\www\Xage\system\helpers\file_helper.php 180
ERROR - 2013-12-13 11:12:32 --> Severity: Warning  --> opendir(./path/to/file.php) [<a href='function.opendir'>function.opendir</a>]: failed to open dir: No such file or directory C:\VertrigoServ\www\Xage\system\helpers\file_helper.php 180
ERROR - 2013-12-13 11:12:49 --> Severity: Warning  --> opendir(http://localhost/Xage/app/Sage/templates/assets/jquery-file-upload/server/php/files/) [<a href='function.opendir'>function.opendir</a>]: failed to open dir: not implemented C:\VertrigoServ\www\Xage\system\helpers\file_helper.php 180
ERROR - 2013-12-13 11:13:24 --> Severity: Notice  --> Use of undefined constant APP_PATH - assumed 'APP_PATH' C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 120
ERROR - 2013-12-13 11:13:24 --> Severity: Warning  --> opendir(APP_PATH,APP_PATH) [<a href='function.opendir'>function.opendir</a>]: ϵͳ�Ҳ���ָ�����ļ��� (code: 2) C:\VertrigoServ\www\Xage\system\helpers\file_helper.php 180
ERROR - 2013-12-13 11:13:24 --> Severity: Warning  --> opendir(APP_PATH) [<a href='function.opendir'>function.opendir</a>]: failed to open dir: No such file or directory C:\VertrigoServ\www\Xage\system\helpers\file_helper.php 180
ERROR - 2013-12-13 15:08:00 --> 404 Page Not Found --> manage/doanalysis
ERROR - 2013-12-13 15:19:16 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:16 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:16 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:16 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:16 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:16 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:19:17 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:22:21 --> Severity: Notice  --> A non well formed numeric value encountered C:\VertrigoServ\www\Xage\app\Sage\application\libraries\PHPExcel_latest\PHPExcel\Style\NumberFormat.php 520
ERROR - 2013-12-13 15:26:55 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 188
ERROR - 2013-12-13 15:27:55 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 188
ERROR - 2013-12-13 15:28:19 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 188
ERROR - 2013-12-13 15:28:48 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 189
ERROR - 2013-12-13 15:30:57 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 189
ERROR - 2013-12-13 15:35:26 --> Severity: Warning  --> require_once(application/libraries/PHPExcel/PHPExcel.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 166
ERROR - 2013-12-13 15:35:42 --> Severity: Warning  --> require_once(application/libraries/PHPExcel/PHPExcel.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 166
ERROR - 2013-12-13 15:35:48 --> Severity: Warning  --> require_once(application/libraries/PHPExcel/PHPExcel.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 166
ERROR - 2013-12-13 15:37:43 --> Severity: Warning  --> require_once(application/libraries/PHPExcel/PHPExcel.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 166
ERROR - 2013-12-13 15:37:57 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 189
ERROR - 2013-12-13 15:38:41 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 189
ERROR - 2013-12-13 15:41:28 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 188
ERROR - 2013-12-13 15:41:54 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 189
ERROR - 2013-12-13 15:42:56 --> Severity: Notice  --> Undefined variable: address C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 190
ERROR - 2013-12-13 15:44:22 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 201
ERROR - 2013-12-13 15:44:22 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 202
ERROR - 2013-12-13 15:44:22 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 203
ERROR - 2013-12-13 15:44:43 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 201
ERROR - 2013-12-13 15:44:43 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 202
ERROR - 2013-12-13 15:44:43 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 203
ERROR - 2013-12-13 15:44:50 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 201
ERROR - 2013-12-13 15:44:50 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 202
ERROR - 2013-12-13 15:44:50 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 203
ERROR - 2013-12-13 15:56:53 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 204
ERROR - 2013-12-13 15:56:53 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 205
ERROR - 2013-12-13 15:56:53 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 206
ERROR - 2013-12-13 15:57:08 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 205
ERROR - 2013-12-13 15:57:08 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 206
ERROR - 2013-12-13 15:57:08 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 207
ERROR - 2013-12-13 15:57:41 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 206
ERROR - 2013-12-13 15:57:41 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 207
ERROR - 2013-12-13 15:57:41 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 208
ERROR - 2013-12-13 15:58:41 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 207
ERROR - 2013-12-13 15:58:41 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 208
ERROR - 2013-12-13 15:58:41 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 209
ERROR - 2013-12-13 16:22:47 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 216
ERROR - 2013-12-13 16:22:47 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 217
ERROR - 2013-12-13 16:22:47 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 218
ERROR - 2013-12-13 16:24:01 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 213
ERROR - 2013-12-13 16:24:01 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 214
ERROR - 2013-12-13 16:24:01 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 215
ERROR - 2013-12-13 16:24:14 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 212
ERROR - 2013-12-13 16:24:14 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 213
ERROR - 2013-12-13 16:24:14 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 214
ERROR - 2013-12-13 16:24:42 --> Severity: Notice  --> Undefined variable: result C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 213
ERROR - 2013-12-13 16:24:42 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 214
ERROR - 2013-12-13 16:24:42 --> Severity: Notice  --> Undefined index: data C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 215
ERROR - 2013-12-13 20:59:26 --> Severity: Notice  --> Undefined property: Manage::$id C:\VertrigoServ\www\Xage\system\core\Model.php 51
ERROR - 2013-12-13 20:59:26 --> Query error: Unknown column ' =  '1'' in 'where clause'
ERROR - 2013-12-13 20:59:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\VertrigoServ\www\Xage\system\core\Exceptions.php:185) C:\VertrigoServ\www\Xage\system\core\Common.php 442
ERROR - 2013-12-13 21:08:23 --> Severity: Warning  --> json_decode() expects parameter 1 to be string, array given C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 158
ERROR - 2013-12-13 21:17:45 --> Severity: Warning  --> urlencode() expects parameter 1 to be string, array given C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 184
ERROR - 2013-12-13 21:52:06 --> Severity: Notice  --> Undefined offset: 0 C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 265
ERROR - 2013-12-13 21:52:06 --> Severity: Notice  --> Undefined offset: 0 C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 267
ERROR - 2013-12-13 21:52:06 --> Severity: Notice  --> Array to string conversion C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 268
ERROR - 2013-12-13 21:52:06 --> Severity: Warning  --> array_diff() [<a href='function.array-diff'>function.array-diff</a>]: Argument #1 is not an array C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 183
ERROR - 2013-12-13 21:52:08 --> Severity: Notice  --> Undefined offset: 0 C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 265
ERROR - 2013-12-13 21:52:08 --> Severity: Notice  --> Undefined offset: 0 C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 267
ERROR - 2013-12-13 21:52:08 --> Severity: Notice  --> Array to string conversion C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 268
ERROR - 2013-12-13 21:52:08 --> Severity: Warning  --> array_diff() [<a href='function.array-diff'>function.array-diff</a>]: Argument #1 is not an array C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 183
ERROR - 2013-12-13 21:53:33 --> Severity: Notice  --> Undefined offset: 0 C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 265
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
ERROR - 2013-12-13 22:52:00 --> Severity: Warning  --> Illegal offset type C:\VertrigoServ\www\Xage\app\Sage\application\controllers\admin\63\manage.php 316
