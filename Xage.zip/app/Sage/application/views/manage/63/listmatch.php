<?php
$match_summary = json_decode($details['result'],true);
$atom = json_decode($details['result_details'],true);
$atom = $atom['name'];

$thisattendee = array();
foreach ($attendee as $each){
	$thisattendee[$each['name']][] = $each;
}

//print_r($atom);

$thiskeys = array();
foreach($keys as $i=>$k){
	$thiskeys[$k] = $vals[$i];
}

?>
<div class="span12">
	<!--BEGIN TABS-->
	<div class="tabbable tabbable-custom">
		<?php if(count($match_summary)>0):?>
		<ul class="nav nav-tabs">
			<?php $i = 0;foreach($match_summary as $key=>$val):?>
			<li <?php if($i==0):?>class="active"<?php endif;?>><a data-toggle="tab" href="#tab_1_<?php echo $i+1;?>"><?php print_r(str_replace(array('matchno','matchone','matchmore'),array('完全没能配对','成功配对','存在配对1对N情况'),$key.'('.$val.')'))?></a></li>
			<?php $i++; endforeach;?>
		</ul>
		<div class="tab-content">
			<?php $i = 0;foreach($match_summary as $key=>$val):?>
			<div id="tab_1_<?php echo $i+1;?>" class="tab-pane <?php if($i==0):?>active<?php endif;?>">
				<!-- BEGIN SAMPLE TABLE PORTLET-->
				<div class="portlet box green">
					<div class="portlet-title">
						<h4><i class="icon-table"></i><?php print_r(str_replace(array('matchno','matchone','matchmore'),array('完全没能配对','成功配对','存在配对1对N情况'),$key.'('.$val.')'))?></h4>
					</div>
					
					<?php
					if($key == 'matchno'){
						$keys = $thiskeys;
						unset($keys['barcode']);
						unset($keys['name']);
						unset($keys['H']);
						//print_r($thiskeys);
					}else{
						$keys = $thiskeys;
					}
					?>
					
					<div class="portlet-body">
						<div class="clearfix">
							<div class="btn-group pull-right open">
								<button data-toggle="dropdown" class="btn dropdown-toggle">Tools <i class="icon-angle-down"></i>
								</button>
								<ul class="dropdown-menu">
									<?php if($key == 'matchone'):?>
									<li><a class="btn_domatch_all" href="javascript:void(0)">全部确认配对</a></li>
									<?php endif;?>
									<li><a href="javascript:void(0)">导出到Excel</a></li>
								</ul>
							</div>
						</div>
						<table class="table table-striped table-hover" id="<?php echo $key;?>">
							<thead>
								<tr>
									<?php foreach($keys as $k=>$v):?>
									<th class="_<?php echo $k;?>"><?php echo $v;?></th>
									<?php endforeach;?>
									<th>操作</th>
								</tr>
							</thead>
							<?php if($val>0):?>
								<?php if($key == 'matchno'):?>
								<tbody>
									<?php foreach($atom[$key] as $each):?>
									<tr>
										<?php foreach($keys as $k=>$v):?>
										<td><?php echo isset($each[$k])?$each[$k]:'';?></td>
										<?php endforeach;?>
										<td> &nbsp; </td>
									</tr>
									<?php endforeach;?>
								</tbody>
								<?php endif;?>
								
								
								<?php if($key == 'matchone'):?>
								<tbody>
									<?php foreach($atom[$key] as $j=>$each):?>
									<tr class="tar_<?php echo $thisattendee[$each['Z']][0]['id'];?> ori_<?php echo $j;?>" ori="<?php echo $j;?>" val="<?php echo $thisattendee[$each['Z']][0]['id'];?>">
										<?php foreach($keys as $k=>$v):?>
										<td <?php if(isset($each[$k])):?>class="ori" key="<?php echo $k;?>"<?php endif;?>><?php echo isset($each[$k])?$each[$k]:$thisattendee[$each['Z']][0][$k];?></td>
										<?php endforeach;?>
										<td><a class="btn mini green btn_domatch" style="width:30px;" href="javascript:void(0)">确认</a></td>
									</tr>
									<?php endforeach;?>
								</tbody>
								<?php endif;?>
								
								
								<?php if($key == 'matchmore'):?>
								<tbody>
									<?php foreach($atom[$key] as $j=>$each):?>
										<?php foreach($thisattendee[$each['Z']] as $thisz):?>
										<tr class="tar_<?php echo $thisz['id'];?> ori_<?php echo $j;?>" ori="<?php echo $j;?>" val="<?php echo $thisz['id'];?>">
											<?php foreach($keys as $k=>$v):?>
											<td <?php if(isset($each[$k])):?>class="ori" key="<?php echo $k;?>"<?php endif;?>><?php echo isset($each[$k])?$each[$k]:$thisz[$k];?></td>
											<?php endforeach;?>
											<td><a class="btn mini green btn_domatch" style="width:30px;" href="javascript:void(0)">确认</a></td>
										</tr>
										<?php endforeach;?>
									<?php endforeach;?>
								</tbody>
								<?php endif;?>
								
							<?php endif;?>
						</table>
					</div>
				</div>
				<!-- END SAMPLE TABLE PORTLET-->
			</div>
			<?php $i++; endforeach;?>
		</div>
		<?php endif;?>
	</div>
	<!--END TABS-->
	<input type="hidden" value="<?php echo site_url('admin/manage/domatch/'.$show_id);?>" id="domatchurl"/>
	<input type="hidden" value="<?php echo site_url('admin/manage/domatchall/'.$show_id);?>" id="domatchallurl"/>
</div>
<script type="text/javascript">
$(document).ready(function(){
	$('#tab3 .btn_domatch').click(function(){
		var tar = $(this).parent().parent();
		
		var data = new Object();
		var params = new Object();

		data.id = tar.attr('val');
		data.ori = tar.attr('ori');
		tar.find('td.ori').each(function(){
			params[$(this).attr('key')] = $(this).text();
		});

		data.params = params;

		var ajurl = $('#domatchurl').attr('value');
		$.ajax({
			url: ajurl,
			type: "POST",
			data: data,
			dataType: 'json',
			async: true,//是否采取异步形式,false为同步
			error: function(){alert('error');},
			success: function (result){
				if(result.error){
					alert(result.error);
				}else{
					if(result.ori){
						tar.parent().find('tr.ori_'+result.ori).each(function(){$(this).find('a').remove()});
						tar.find('td:last-child').html('<i class="icon-ok"></i> ');
					}
				}
			}
		});
	});

	$('#tab3 .btn_domatch_all').click(function(){
		var all = new Object();

		$('table#matchone tbody').find('tr').each(function(i){
			var tar = $(this);
			var data = new Object();
			var params = new Object();

			data.id = tar.attr('val');
			data.ori = tar.attr('ori');
			tar.find('td.ori').each(function(){
				params[$(this).attr('key')] = $(this).text();
			});

			data.params = params;
			all[i] = data;
		});

		var ajurl = $('#domatchallurl').attr('value');
		$.ajax({
			url: ajurl,
			type: "POST",
			data: all,
			dataType: 'json',
			async: true,//是否采取异步形式,false为同步
			error: function(){alert('error');},
			success: function (result){
				if(result.error){
					alert(result.error);
				}else{
					$.each(result,function(i,v){
						if(v.ori){
							$('table#matchone tbody').find('tr.ori_'+v.ori).each(function(){$(this).find('a').remove()});
							$('table#matchone tbody').find('tr.ori_'+v.ori).find('td:last-child').html('<i class="icon-ok"></i> ');
						}
					});
					
				}
			}
		});
	});
});
</script>
